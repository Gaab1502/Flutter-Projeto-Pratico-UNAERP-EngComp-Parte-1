import 'package:flutter_projeto_pratico_unaerp_engcomp_parte_1/view/tela_login.dart';
import 'package:flutter_projeto_pratico_unaerp_engcomp_parte_1/view/tela_logo.dart';
import 'package:flutter_projeto_pratico_unaerp_engcomp_parte_1/view/tela_cadastro.dart';
import 'package:flutter_projeto_pratico_unaerp_engcomp_parte_1/view/tela_principal.dart';
import 'package:flutter_projeto_pratico_unaerp_engcomp_parte_1/view/tela_sobre.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dubdogz',
      initialRoute: 'tela1',
      routes: {
        'tela1' : (context) => const TelaLogo(),
        'tela2' : (context) => const TelaLogin(),
        'tela3' : (context) => const TelaCadastro(),
        'tela4' : (context) => const TelaPrincipal(),
        'tela5' : (context) => const TelaSobre(),
      },
    ),
    
  );
}