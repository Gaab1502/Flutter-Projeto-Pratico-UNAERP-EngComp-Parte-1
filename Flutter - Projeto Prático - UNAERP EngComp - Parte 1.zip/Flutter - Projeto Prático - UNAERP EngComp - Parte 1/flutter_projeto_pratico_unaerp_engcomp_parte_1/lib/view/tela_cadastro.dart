import 'package:flutter/material.dart';

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({Key? key}) : super(key: key);

  @override
  _TelaCadastroState createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  var txtEmail = TextEditingController();
  var txtSenha = TextEditingController();
  var form = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Center(
            child: Form(
              key: form,
              child: Column(
                children: [
                  const Icon(
                    Icons.person_add_outlined,
                    size: 100,
                  ),
                  const Text(
                    'Cadastro',
                    style: TextStyle(
                        fontSize: 24,
                        fontFamily: 'Caviar',
                        fontWeight: FontWeight.w300),
                  ),
                  const SizedBox(height: 30),
                  campoTexto('Email', txtEmail, false),
                  const SizedBox(height: 10),
                  campoTexto('Senha', txtSenha, true),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      botao('Voltar', 'tela2'),
                      botao('Cadastrar', 'tela2'),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  campoTexto(rotulo, variavel, obscuro) {
    return TextFormField(
      controller: variavel,
      style: const TextStyle(
          fontSize: 24, fontFamily: 'Caviar', fontWeight: FontWeight.w300),
      keyboardType: TextInputType.text,
      //obscureText: obscuro,
      maxLength: 30,
      decoration: InputDecoration(
        labelText: rotulo,
        labelStyle: const TextStyle(
            fontSize: 24, fontFamily: 'Caviar', fontWeight: FontWeight.w300),
        hintStyle: TextStyle(
          fontSize: 18,
          color: Colors.grey.shade400,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),
    );
  }

  botao(rotulo, dir) {
    return SizedBox(
      width: 150,
      height: 80,
      child: ElevatedButton(
        onPressed: () {
          Navigator.pushNamed(context, dir);
        },
        child: Text(
          rotulo,
          style: const TextStyle(
              fontSize: 24, fontFamily: 'Caviar', fontWeight: FontWeight.w300),
        ),
        style: ElevatedButton.styleFrom(
          primary: Colors.black,
        ),
      ),
    );
  }
}
