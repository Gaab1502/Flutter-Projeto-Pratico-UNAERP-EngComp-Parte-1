import 'package:flutter/material.dart';

import 'widget_album.dart';

class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({ Key? key }) : super(key: key);

  @override
  _TelaPrincipalState createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dubdogz', style: TextStyle(
          fontSize: 20.0, 
          fontFamily: 'Caviar', 
          fontWeight: FontWeight.w300
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.grey,
      ),

      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: const [
              WidgetAlbum("Jazz Club", "assets/images/Jazz_Club.jpg"),
              WidgetAlbum("Sun Goes Down (Sound Of Violence)", "assets/images/Sun_Goes_Down_(Sound_Of_Violence).jpg"),
              WidgetAlbum("Give It Up", "assets/images/Give_It_Up.jpg")
            ]
          ),
        )
      ),

      drawer: Container(
        color: Colors.grey,
        child: Column(children: [
          TextButton(
            style: TextButton.styleFrom(),
            onPressed: (){Navigator.pushNamed(context, 'tela4');},
            child: const Text("Tela Principal", style: const TextStyle(color: Colors.black, fontSize: 30)),
            
          ),
          TextButton(
            style: TextButton.styleFrom(),
            onPressed: (){Navigator.pushNamed(context, 'tela5');},
            child: const Text("Sobre", style: const TextStyle(color: Colors.black, fontSize: 30)),
            
          )
        ]
        ),
      ),

    );
  }
}