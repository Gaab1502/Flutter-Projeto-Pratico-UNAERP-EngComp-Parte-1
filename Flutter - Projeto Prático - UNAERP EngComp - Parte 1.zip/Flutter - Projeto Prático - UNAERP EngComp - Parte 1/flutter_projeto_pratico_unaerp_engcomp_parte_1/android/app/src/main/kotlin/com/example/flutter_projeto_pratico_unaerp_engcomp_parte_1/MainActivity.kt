package com.example.flutter_projeto_pratico_unaerp_engcomp_parte_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
